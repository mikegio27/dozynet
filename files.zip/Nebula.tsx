export default function Nebula() {
  return (
    <div className="nebula">
      <svg
        viewBox="0 0 1200 900"
        xmlns="http://www.w3.org/2000/svg"
        preserveAspectRatio="xMidYMid slice"
      >
        <defs>
          <radialGradient id="n1" cx="15%" cy="20%" r="45%">
            <stop offset="0%" stopColor="#bb9af7" stopOpacity="0.20" />
            <stop offset="100%" stopColor="#bb9af7" stopOpacity="0" />
          </radialGradient>
          <radialGradient id="n2" cx="85%" cy="10%" r="40%">
            <stop offset="0%" stopColor="#7aa2f7" stopOpacity="0.16" />
            <stop offset="100%" stopColor="#7aa2f7" stopOpacity="0" />
          </radialGradient>
          <radialGradient id="n3" cx="55%" cy="75%" r="50%">
            <stop offset="0%" stopColor="#2ac3de" stopOpacity="0.12" />
            <stop offset="100%" stopColor="#2ac3de" stopOpacity="0" />
          </radialGradient>
          <radialGradient id="n4" cx="8%" cy="85%" r="38%">
            <stop offset="0%" stopColor="#ff79c6" stopOpacity="0.09" />
            <stop offset="100%" stopColor="#ff79c6" stopOpacity="0" />
          </radialGradient>
          <radialGradient id="n5" cx="92%" cy="60%" r="32%">
            <stop offset="0%" stopColor="#bb9af7" stopOpacity="0.10" />
            <stop offset="100%" stopColor="#bb9af7" stopOpacity="0" />
          </radialGradient>
          <radialGradient id="n6" cx="45%" cy="40%" r="28%">
            <stop offset="0%" stopColor="#7aa2f7" stopOpacity="0.07" />
            <stop offset="100%" stopColor="#7aa2f7" stopOpacity="0" />
          </radialGradient>
          <filter id="gblur">
            <feGaussianBlur stdDeviation="28" />
          </filter>
        </defs>

        <rect width="1200" height="900" fill="#0d0e1a" />
        <ellipse cx="180"  cy="180" rx="380" ry="260" fill="url(#n1)" filter="url(#gblur)" />
        <ellipse cx="1020" cy="90"  rx="320" ry="220" fill="url(#n2)" filter="url(#gblur)" />
        <ellipse cx="660"  cy="675" rx="400" ry="300" fill="url(#n3)" filter="url(#gblur)" />
        <ellipse cx="96"   cy="765" rx="260" ry="190" fill="url(#n4)" filter="url(#gblur)" />
        <ellipse cx="1104" cy="540" rx="220" ry="170" fill="url(#n5)" filter="url(#gblur)" />
        <ellipse cx="540"  cy="360" rx="200" ry="150" fill="url(#n6)" filter="url(#gblur)" />

        {/* Stars */}
        <circle cx="110"  cy="65"  r="1"   fill="#c0caf5" opacity="0.6" />
        <circle cx="310"  cy="40"  r="0.8" fill="#7aa2f7" opacity="0.7" />
        <circle cx="530"  cy="85"  r="1.2" fill="#c0caf5" opacity="0.4" />
        <circle cx="740"  cy="30"  r="0.7" fill="#bb9af7" opacity="0.8" />
        <circle cx="920"  cy="70"  r="1"   fill="#c0caf5" opacity="0.5" />
        <circle cx="1100" cy="45"  r="0.8" fill="#2ac3de" opacity="0.5" />
        <circle cx="210"  cy="155" r="0.6" fill="#c0caf5" opacity="0.4" />
        <circle cx="460"  cy="50"  r="1"   fill="#c0caf5" opacity="0.35" />
        <circle cx="680"  cy="110" r="0.7" fill="#7aa2f7" opacity="0.5" />
        <circle cx="870"  cy="140" r="0.9" fill="#bb9af7" opacity="0.4" />
        <circle cx="50"   cy="300" r="0.7" fill="#c0caf5" opacity="0.3" />
        <circle cx="1150" cy="200" r="0.8" fill="#c0caf5" opacity="0.35" />
        <circle cx="390"  cy="185" r="0.6" fill="#2ac3de" opacity="0.45" />
        <circle cx="770"  cy="200" r="1"   fill="#c0caf5" opacity="0.3" />
        <circle cx="1050" cy="310" r="0.7" fill="#bb9af7" opacity="0.4" />
      </svg>
    </div>
  )
}
